export class CreateAuthDto {
    email:string;
    password:string;
    isAdmin:number
}
