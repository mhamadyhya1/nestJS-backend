export const jwtConstants = {
    secret: 'n2r5u8x/A?D(G+KbPeShVmYq3s6v9y$B',
};