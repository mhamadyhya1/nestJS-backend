type Payload = {
    id: string;
};